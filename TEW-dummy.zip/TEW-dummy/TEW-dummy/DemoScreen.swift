//
//  DemoScreen.swift
//  TEW-dummy
//
//  Created by Christian Vargas on 6/15/18.
//  Copyright © 2018 Christian Vargas. All rights reserved.
//

import UIKit
import paper_onboarding

class DemoScreen: UIViewController {

    @IBOutlet weak var onboardingObj: OnboardingViewClass!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        onboardingObj.dataSource = self
        
    }


}

extension DemoScreen: PaperOnboardingDataSource {
   
    func onboardingItemsCount() -> Int {
        return 1
    }
    
    func onboardingItem(at index: Int) -> OnboardingItemInfo {
        let bgOne = #colorLiteral(red: 0.9529411765, green: 0.4470588235, blue: 0.3294117647, alpha: 1)
        let bgTwo = #colorLiteral(red: 0.2392156869, green: 0.6745098233, blue: 0.9686274529, alpha: 1)
        let bgThree = #colorLiteral(red: 0.8078431487, green: 0.02745098062, blue: 0.3333333433, alpha: 1)
        
        let textColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
        
        
        let titleFont = UIFont(name: "HelveticaNeue-Bold", size: 18)!
        let descFont = UIFont(name: "HelveticaNeue", size: 14)!
    
        return [(#imageLiteral(resourceName: "illustration"), "Beer", "Beer is awesome.", #imageLiteral(resourceName: "active"), bgOne, textColor, textColor, titleFont, descFont)][0]
    }
}
