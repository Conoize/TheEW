//
//  OnboardingViewClass.swift
//  TEW-dummy
//
//  Created by Christian Vargas on 6/15/18.
//  Copyright © 2018 Christian Vargas. All rights reserved.
//

import UIKit
import paper_onboarding

class OnboardingViewClass: PaperOnboarding {

    
    
}
